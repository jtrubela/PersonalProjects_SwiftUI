//
//  userClass.swift
//  MScoots
//
//  Created by Justin Trubela on 2/27/23.
//

import Foundation

