import UIKit
import Darwin

///*
//    DAY 1: Strings/Variables/Constants/Integers/Doubles/
// */
//var greeting = "Hello, playground"
//
//var name: String = "Ted"
//name = "Rebecca"
//name = "Keeley"
//
//var playerName = "Roy"
//print("Hi, my name is \(playerName)")
//playerName = "Danny"
//print("Hi, my name is \(playerName)")
//playerName = "Sam"
//print("Hi, my name is \(playerName)")
//
//let managerName = "Michael Scott"
//print(managerName)
//let dogBreed = "Retriever"
//
//
//var meaningOfLife = 42
//
//
//print(greeting)
//print("Hi, my name is \(name)")


//        /*
//            DAY 2:  Booleans/String Interpolation
//         `          LEARNED:    .toggle(), .uppercased(), isMultiple(of: int)
//                    BONUS:      Still remember how to create and utilize functions
//         */
//        let celciusTemp: Double = 100
//        print("\(celciusTemp)°C in fahrenheit is \((celciusTemp*9)/5)°F")
//
//        func tempConversion(temp: Double) -> String {
//            let convertedTemp = temp*9/5
//            return "\(temp)°C in fahrenheit is \(convertedTemp)°F"
//        }
//        tempConversion(temp: 120)
//
//        var day = 2
//        var completionStatus = false
//        completionStatus.toggle()
//        print("Day \(day)/100 of #100DaysOfSwiftUI: Status:\(completionStatus)")

///*
//    DAY 3: COMPLEX DATA TYPES - ARRAYS, DICTIONARIES, SETS, AND ENUMS
//                    "Lots of rules and no mercy"
// */
//
//var beatles = ["John", "Paul", "George", "Ringo"]
//let numbers = [4, 8, 15, 16, 23, 42]
//var temperatures = [25.3, 28.2, 26.4]
//
//print(beatles[0])
//print(numbers[1])
//print(temperatures[2])
//
//beatles.append("Adrian")
//
//beatles.append("Allen")
//beatles.append("Adrian")
//beatles.append("Novall")
//beatles.append("Vivian")
//
////temperatures.append("Chris")
//
//let firstBeatle = beatles[0]
//let firstNumber = numbers[0]
////let notAllowed = firstBeatle + firstNumber
//
//var scores = Array<Int>()
//scores.append(100)
//scores.append(80)
//scores.append(85)
//print(scores[1])
//
var albums = Array<String>()
albums.append("Folklore")
albums.append("Fearless")
albums.append("Red")
//
//var characters = ["Lana", "Pam", "Ray", "Sterling"]
//print(characters.count)
//
//characters.remove(at: 2)
//print(characters.count)
//
//characters.removeAll()
//print(characters.count)
//
//let bondMovies = ["Casino Royale", "Spectre", "No Time To Die"]
//print(bondMovies.contains("Frozen"))

/*
    DAY 4: COMPLEX DATA TYPES PT2 - Type annotation
                    "Good data structures and bad code works alot better than the other way around"
 */
//
//var name: String = "Roy"
//var score: Int = 0
//var doubleScore: Double = 0
//
//let playerNAme: String = "Ted"
//var luckyNumber: Int = 13
//let pi: Double = 3.14
//var isAuthenticated: Bool = true
//
//var albums: [String] = ["Red","Fearless"]
//var user: [String: String] = ["id": "@jrtrubela"]
//var books: Set<String> = Set(["The Bluest Eye", "Foundation", "Girl, Woman, Other"])
//
//var soda: [String] = ["Coke", "Pepsi", "Irn-Bru"]
//var teams: [String] = [String]()
//var cities: [String] = []
//var clues = [String]()
//
//enum UIStyle {
//    case light, dark, system    }
//enum daysOfWeek {   case Monday, Tuesday, Wednesday, Thursday, Friday, Saturday, Sunday     }
//var today = daysOfWeek.Monday
//
//var style: UIStyle = UIStyle.light
//style = .dark
//
//let userName: String
//userName = "@jrtrubela"
//
//
//
// //CHECKPOINT 2: Create an array of string , then write some code that prints the number of items in the array and also the number of unique items in the array
//
// var myArray: [String] = ["I ", "just ","completed ", "my ", "4th ", "day", "of ", "hacking with ", "SwiftUI", "SwiftUI"]
// print(myArray)
// print("Number of items in array: \(myArray.count)")
// print("My array contains \"SwiftUI\": \(myArray.contains("SwiftUI"))")
//
// var myArraySet:Set = Set(myArray)
// print("Number of unique elements in my set: \(myArraySet.count)")
//
// print(myArraySet)
//
//

///*
//    DAY 5: To be || !To be
// */
//
//enum Weather{
//    case sun,rain,wind,snow,unknown
//}
//
//let forecast = Weather.sun
//
//switch forecast{                                // switch replaces if/else statements
//case .sun:      print("It should be a nice day.")
//case .rain:     print("Pack an umbrella")
//case .wind:     print("Wear a windbreaker")
//case .snow:     print("clean your car off")
//case .unknown:  print("Our forecast generator is broken");fallthrough
//default:        print("blah")
//}
//
//let place = "metropolis"
//
//switch place {
//case "gotham":          print("You're Batman")
//case "mega-city one":   print("You're Judge Dredd")
//case "wakanda":         print("You're Black Panther")
//default:                print("Who are you?")
//}
//
//
//
//SWITCHES WITH INTEGER CASES
//
//let day = 5
//print("my true love gave to me")
//
//switch day{
//case 5:print("5 golden rings");fallthrough
//case 4:print("4 calling birds");fallthrough
//case 3:print("3 french hens");fallthrough
//case 2:print("2 turtle doves");fallthrough
//default:print("partidge in a pair tree")
//
//
//var temp: Int  = 80
//switch temp {
//case 79: print("its not hot")
//case 80: print("its nice out")
//case 81: print("its hot")
//default: print("temp gauge is broken")
//}
//
//// Ternary Conditional Operator
//let isAuthenticated = true
////          What            True         False
//print(isAuthenticated ? "Welcome!" : "Who are you?")


/*
        Day 6: Loops
 */

//for i in 1...12 {
//    print("The \(i) times table:")
//    for j in 1...12 {
//        print("  \(j) x \(i) is \(j * i)")
//    }
//    print(" index i is \(i)")
//}
//
//let names = ["Piper", "Alex", "Suzanne", "Gloria"]
////We could read out an individual name like this:
//print(names[0])
//
////With ranges, we can also print a range of values like this:
//print(names[1...3])
////That carries a small risk, though: if our array didn’t contain at least four items then 1...3 would fail.
//
////Fortunately, we can use a one-sided range to say “give me 1 to the end of the array”, like this:
//print(names[1...])
//
//
//var roll = 0
//
//while roll != 20{
//    roll = Int.random(in: 1...20)
//        print("not enough damage done")
//}
//print("Critical hit")
//
//
//var page: Int = 0
//while page <= 5 {
//    page += 1
//    print("I'm reading page \(page).")
//}
//
///*
// CHECKPOINT 3
// Your goal is to loop from 1 through 100, and for each number:
//
// If it’s a multiple of 3, print “Fizz”
// If it’s a multiple of 5, print “Buzz”
// If it’s a multiple of 3 and 5, print “FizzBuzz”
// Otherwise, just print the number.
// */
//for num in 1...100{
//    if (num%5==0 && num%3 != 0){
//        print("\(num): buzz")
//    }
//    else if (num%3==0 && num%5 != 0){
//        print("\(num): fizz")
//    }
//    else if (num%3==0 && num%5 == 0 || num.isMultiple(of: 5) && num.isMultiple(of: 3)){
//        print("\(num): fizz buzz")
//    }
//    else {
//        print(num)
//    }
//}

///*
// DAY 7 - Functions, PT.1
// */
//
//func multiply(num: Int,by: Int) -> Int{
//    let result = num*by
//
//    return result;
//}
//multiply(num: 1, by: 2)
//
//func divide(num: Int, by: Int) -> Int{
//    let result = num/by
//
//    return result;
//}
//
//divide(num: 12, by: 3)
//multiply(num: divide(num: 12, by: 4), by: 2)
//
//
//func rollDice() -> Int {
//    return Int.random(in: 1...6)
//}
//let result = rollDice()
//print(result)
//
//func sameLetters(s1: String,s2: String)->Bool{
//    s1.sorted() == s2.sorted()                  // since its only one line of code we do not need to return, it knows to return the value
//    return s1.sorted() == s2.sorted()
//
//    for i in s1 {
//        if s2.contains(i){
//            result = true
//            break
//        }
//        else{
//            continue
//        }
//    }
//    return result
//
//}
//var s1 = "String"
//var s2 = "String"
//sameLetters(s1: s1, s2: s2)
//
//func pythagorus(a: Double, b: Double) -> Double{
//    sqrt((a*a+b*b))
//}
//var a = pythagorus(a: 3, b: 4)
//print(a)
//
//func greet(name: String) -> String {
//    name == "Taylor Swift"
//    ?"oh wow" : "hello \(name)"
//}
//
//print(greet(name: "Taylor Swift"))
//
//
///**********************************************************************************************************************************************************************************/
//
//                                        func getName() -> (firstName: String, lastName: String){
//                                                          (firstName: "Taylor", lastName: "Swift")            }
///*DESTRUCTURING A TUPLE*/
//                                        let (firstName, lastName) = getName()
//                                        print(firstName, lastName)
//
///**********************************************************************************************************************************************************************************/
//
//
//
//func getUser() -> (firstNameUser: String, lastNameUser: String) {
//    ("User", "2")
//}
//
//let (firstNameUser, lastNameUser) = getUser()
//print(firstNameUser,lastNameUser)
//
//
//var score = (10,"winner")
////score = (10, 10)
//
//print(score.0)
//
//func isUppercase(_: String) -> Bool {
//    string==string.uppercased()
//}
//
//let string = "HELLO, WORLD"
//isUppercase(string)
//
//func printTimesTable(for num: Int) {            //adding an external name(for) for the paramater while still keeping internal parameter call                                                    (num) syntactically logical
//    for i in 1...12 {
//            print("\(i) x \(num) = \(i*num)")
//    }
//}
//
//print
//printTimesTable(for: 6)
//
//
//
//
//
//
//
//
//func multiplyBy(by:Int)->Int{
//    let num = 5
//    return num*by
//}
//multiplyBy(by: 5)
//
//func multiplyBy(_ num: Int)->Int{
//    5*num
//}
//multiplyBy(5)
//


///*
//    DAY 8: Functions PT2: Handling errors
// */
//
////You can default any or all of the paramaters in your function by initializing them to a "default value"
//
//func timesTable(for number: Int, range: Int = 10){
//    for i in 0...range{
//        print("\(number) * \(i) = \(number * i)")
//    }
//}
////timesTable(for: 5, range: 10)      =       timesTable(for: 5)
//
////swift gives enough memory to hold the array data plus a little extra
//// sometimes you want to remove data but you know that your going to add alot more
//// so to save time we call this to save some "time"
//var array = ["Hello,", "this", "shows", "default", "value", "for", "arrays"]
//array.count
//array.removeAll(keepingCapacity: false)
//array.count
//
/*
    HANDLING ERRORS IN FUNCTIONS
    Step1: define all the errors that might happen in the code were writing
    Step2: write a function that runs as normal but checks for these errors
    Step3: try and run that function and handle any errors that come back
 */

//Define errors
//enum PasswordError: Error {
//    case short, obvious
//}
//
////Check for errors
//func checkPassword(_ password: String) throws -> String {
//    if password.count < 5 {throw PasswordError.short}
//    if password == "12345" {throw PasswordError.obvious}
//
//    if password.count < 8{
//        return "ok"
//    }
//    else if password.count < 10 {
//        return "good"
//    }
//    else {
//        return "excelent"
//    }
//}
//let string = "12345"
//
//do {
//    let result = try checkPassword(string)
//    print("password rating: \(result)")
//}
//catch PasswordError.obvious{
//    print("I have the same password on my luggage!")
//}
//catch PasswordError.short{
//    print("Password must be greater than 5 characters")
//}
//catch{
//    print("There was an error:  \(error.localizedDescription)")
//}
////checkPassword("123456")
//
//
//
///*
// Checkpoint 4
// We’ve covered a lot about functions in the previous chapters, so let’s recap:
//
// Functions let us reuse code easily by carving off chunks of code and giving it a name.
// All functions start with the word func, followed by the function’s name. The function’s body is contained inside opening and closing braces.
// We can add parameters to make our functions more flexible – list them out one by one separated by commas: the name of the parameter, then a colon, then the type of the parameter.
// You can control how those parameter names are used externally, either by using a custom external parameter name or by using an underscore to disable the external name for that parameter.
// If you think there are certain parameter values you’ll use repeatedly, you can make them have a default value so your function takes less code to write and does the smart thing by default.
// Functions can return a value if you want, but if you want to return multiple pieces of data from a function you should use a tuple. These hold several named elements, but it’s limited in a way a dictionary is not – you list each element specifically, along with its type.
// Functions can throw errors: you create an enum defining the errors you want to happen, throw those errors inside the function as needed, then use do, try, and catch to handle them at the call site.
// */
//
//
///*The challenge is this: write a function that accepts an integer from 1 through 10,000, and returns the integer square root of that number. That sounds easy, but there are some catches:
//
// -You can’t use Swift’s built-in sqrt() function or similar – you need to find the square root yourself.
//
// -If the number is less than 1 or greater than 10,000 you should throw an “out of bounds” error.
//
// -You should only consider integer square roots – don’t worry about the square root of 3 being 1.732, for example.
//    If you can’t find the square root, throw a “no root” error.
// */
//
////Step1: declare a set of valid throw cases
//enum squarerootError: Error { case noRoot, outOfBounds }
//
////Step2: Write the function that will catch the errors
//func squareRoot(of number: Int) throws -> Int{
//    var root = 0
//    if number < 1 || number > 10_000{ throw squarerootError.outOfBounds }      //Catch error: OutOfBounds
//    for i in 1...100{
//        if i*i == number {
//            root = i
//            break
//        }
//        else if root == 0 && i == 100{ throw squarerootError.noRoot }
//    }
//    return root
//}
////Step3: Call the function and handle the errors
//let number = 100
//
//do{    //Try finding the square root for the number given
//    try squareRoot(of: number)
//    print("There is a root for \(number): \(sqrt(Double(number)))")
//}
////Catch all cases for an error
//catch squarerootError.noRoot{
//    print("No root")
//}
//catch squarerootError.outOfBounds{
//    print("out of bounds")
//}
//catch{
//    print("cannot compute")
//}
//

/*
 DAY 9: CLOSURES
 */
//
//
//func greetUser() {
//    print("Hi there!")
//}
//
////How to create and use closures
//let sayHello = { (name: String) -> String in
//    "Hi there\(name)!"
//}
//
//sayHello("Justin")
//
//greetUser()
//var greetCopy:() -> Void = greetUser
////var greetCopyFunctionValue = greetCopy()
//
//func getUserData(for id: Int) -> String {
//    if id == 1989 {
//        return "Taylor Swift"
//    }
//    else {
//        return "Anonymous"
//    }
//}
//
//let data: (Int) -> String = getUserData
//let user = data(1989)
//print(user)
//
//
//
//let team = ["Gloria","Suzanne","Piper","Tiffany","Tasha"]
//let sortedTeam = team.sorted()
//print(sortedTeam)
//
////We want suzanne to come first since she is the captain
//
//func captainFirstSorted(name1: String, name2: String) -> Bool {
//    if name1 == "Suzanne"{
//        return true
//    }
//    else if name2 == "Suzanne"{
//        return false
//    }
//        return name1 < name2
//}
//
////let captainFirstTeam = team.sorted(by: captainFirstSorted)
////print(captainFirstTeam)
//
//
//// were condensing both the function call and the sort call into one closure
//
//let captainFirstTeam =  team.sorted(by: { (name1: String, name2: String) -> Bool in
//    if name1 == "Suzanne"{
//        return true
//    }
//    else if name2 == "Suzanne"{
//        return false
//    }
//        return name1 < name2
//})
//print(captainFirstTeam)
//
//let greetUser1 = {
//    print("Hi there!")
//}
//print(greetUser1)
//
//var pickFruit = { (name: String) in
//    switch name {
//    case "strawberry":
//        fallthrough
//    case "raspberry":
//        print("Strawberries and raspberries are half price!")
//    default:
//        print("We don't have those.")
//    }
//}
//
//pickFruit("strawberry")
//
//var cutGrass = { (currentLength: Double) in
//    switch currentLength {
//    case 0.0...1.0:
//        print("That's too short")
//    case 1...3:
//        print("It's already the right length")
//    default:
//        print("That's perfect.")
//    }
//}
//cutGrass(0.5)
//
//
//// How to use trailing colosures and shorthand syntax
////reducing amount of syntax that comes with closures
//
//let reverseTeam = team.sorted { $0 > $1}
//print(reverseTeam)
//
//
////How tto accept functions as paramaters
////thanks to trailing closure syntax
//
//func makeArray(size:Int, using generator: () -> Int) -> [Int] {
//    var numbers = [Int]()
//
//    for _ in 0..<size {
//        let newNumber = generator()
//        numbers.append(newNumber)
//    }
//
//    return numbers
//}
//
//let rolls = makeArray(size: 50) {
//    Int.random(in: 1...20)
//}
//
//func generateNumber() -> Int {
//    Int.random(in: 1...20)
//}
//
//let newRolls = makeArray(size: 50, using: generateNumber)
//print(rolls)
//
//
//func doImportantWork(first: () -> Void, second: () -> Void, third: () -> Void) {
//    print("About to start first work")
//    first()
//    print("About to start second work")
//    second()
//    print("About to start third work")
//    third()
//    print("Done")
//}
//
//doImportantWork {
//    print("this is first work")
//}
//second:{
//        print("this is second work")
//}
//third: {
//    print("this is third work")
//}
//
//let awesomeTalk = {
//    print("Here's a great talk!")
//}
//func deliverTalk(name: String, type: () -> Void) {
//    print("My talk is called \(name)")
//    type()
//}
//deliverTalk(name: "My Awesome Talk", type: awesomeTalk)
//
//
//func goOnVacation(to destination: String, _ activities: () -> Void) {
//    print("Packing bags...")
//    print("Getting on plane to \(destination)...")
//    activities()
//    print("Time to go home!")
//}
//goOnVacation(to: "Mexico") {
//    print("Go sightseeing")
//    print("Relax in sun")
//    print("Go hiking")
//}
//
/////*
//// You can copy functions in Swift, and they work the same as the original except they lose their external parameter names.
//// All functions have types, just like other data types. This includes the parameters they receive along with their return type, which might be Void – also known as “nothing”.
//// You can create closures directly by assigning to a constant or variable.
//// Closures that accept parameters or return a value must declare this inside their braces, followed by the keyword in.
//// Functions are able to accept other functions as parameters. They must declare up front exactly what data those functions must use, and Swift will ensure the rules are followed.
//// In this situation, instead of passing a dedicated function you can also pass a closure – you can make one directly. Swift allows both approaches to work.
//// When passing a closure as a function parameter, you don’t need to explicitly write out the types inside your closure if Swift can figure it out automatically. The same is true for the return value – if Swift can figure it out, you don’t need to specify it.
//// If one or more of a function’s final parameters are functions, you can use trailing closure syntax.
//// You can also use shorthand parameter names such as $0 and $1, but I would recommend doing that only under some conditions.
//// You can make your own functions that accept functions as parameters, although in practice it’s much more important to know how to use them than how to create them.
//// */
//
//
///*
// CHECKPOINT 5
//
// With closures under your belt, it’s time to try a little coding challenge using them.
//
// You’ve already met sorted(), filter(), map(), so I’d like you to put them together in a chain – call one, then the other, then the other back to back without using temporary variables.
//
// Your input is this:
//
// let luckyNumbers = [7, 4, 38, 21, 16, 15, 12, 33, 31, 49]
// Your job is to:
//
// Filter out any numbers that are even
// Sort the array in ascending order
// Map them to strings in the format “7 is a lucky number”
// Print the resulting array, one item per line
// So, your output should be as follows:
//
// 7 is a lucky number
// 15 is a lucky number
// 21 is a lucky number
// 31 is a lucky number
// 33 is a lucky number
// 49 is a lucky number
// If you need hints they are below, but honestly you should be able to tackle this one either from memory or by referencing recent chapters in this book.
// */
//
//
//let luckyNumbers = [7, 4, 38, 21, 16, 15, 12, 33, 31, 49]
//
//
//let luckyOddNumbers = luckyNumbers.filter { number in
//    if number % 2 == 0 {
//        return false
//    }
//    else {
//        return true
//    }
//}.sorted {
//    $0 < $1
//}.map { number in
//    return "\(number) is a lucky number"
//}
//print(luckyOddNumbers)
//

/*
    Day 10 - Structs PT.1 - create our own data types out of a bunch of different small types
 */

// similar to Objects in java, create the object with the given attributes
//struct Album {
//    let title: String
//    let artist: String
//    let year: Int
//
//    func printSummary() {
//        print("\(title) (\(year)) by \(artist)")
//    }
//}
//
//Album(title: "1989", artist: "Taylor Swift", year: 2011)
////
//let tSwift = Album.init(title: "1989", artist: "Taylor Swift", year: 2011)
//print(tSwift)
//tSwift.printSummary()
//
//
////if structs instance is CONSTANT than data inside is immutable
//// change the func to a MUTATING FUNCTION
//struct Employee {
//    //properties
//    var name: String
//    var vacationRemaining = 35
//    var position: String
//
//    //methods
//    mutating func takeVacation(days: Int) {
//        if vacationRemaining > days {
//            vacationRemaining -= days
//            print("I'm going on vacation!")
//            print("Days remaining: \(vacationRemaining)")
//        }
//        else{
//            print("Oops! There aren't enough days remaining")
//        }
//    }
//    func printSummary(){
//        print("Employee(\(position)): \(name), has \(vacationRemaining) vacation days remaining")
//    }
//
//    mutating func fireEmployee() -> Employee {
//        let position = position.self
//        name = "no employee"
//        vacationRemaining = 35
//        return Employee(name: name, position: position)
//    }
//
//}
//
//var dataAnalyst = Employee.init(name: "Justin Trubela", position: "Data Analyst")
//var manager = Employee.init(name: "Monica Applebottom", position: "Manager")
//var leadProgrammer = Employee.init(name: "James Olatunji", position: "Lead Programmer")
//
//dataAnalyst.takeVacation(days: 1)
//dataAnalyst.printSummary()
//
//manager.takeVacation(days: 7)
//manager.printSummary()
//
//leadProgrammer.printSummary()
//leadProgrammer.fireEmployee()
//leadProgrammer.printSummary()
//
//manager.printSummary()
//manager.fireEmployee()
//manager.printSummary()
//
//
////Difference between a struct and a tuple
//    // tuple is a struct without a name
//    // updating information with a tuple can be quite tedious
//
////Difference between a function and a method
//    //functions alone do not belong anywhere
//    //functions inside structs(methods) belong to that object and that object alone unless inherited by a child
//
//struct Delorean {
//    var speed = 0
//    mutating func accelerate() {
//        speed += 1
//        if speed == 88 {
//            travelThroughTime()
//        }
//    }
//    func travelThroughTime() {
//        print("Where we're going we don't need roads.")
//    }
//}
//
//var myCar = Delorean()
//for _ in 1...100{
//    myCar.accelerate()
//}
//print(myCar.speed)
//myCar.travelThroughTime()
//
//
////How to compute property values dynamically
////stored property is a variable or constant that holds a piece of data inside an instance of the struct
////computed property calculates the value of the property dynamically everytime
//
//struct EmployeeComputed {
//    let name: String
//    var vacationAllocated = 14
//    var vacationTaken = 0
//
//    var vacationRemaining: Int {
//        //get the value for this calculation and set it with a new value
//        get{ vacationAllocated - vacationTaken }
//        set{ vacationAllocated = vacationTaken + newValue }
//    }
//}
//
//var Justin = EmployeeComputed(name: "Justin Trubela", vacationAllocated: 14)
//Justin.vacationTaken += 4
//print(Justin.vacationAllocated)
//Justin.vacationRemaining = 5
//print(Justin.vacationAllocated)
//
//struct Code {
//    var language: String
//    var containsErrors = false
//    var report: String {
//        if containsErrors {
//            return "This \(language) code has bugs!"
//        } else {
//            return "This looks good to me."
//        }
//    }
//}
//
////willSet and didSet
//
//struct App {
//    var contacts = [String]() {
//        willSet {
//            print("Current value is: \(contacts)")
//            print("New value will be: \(newValue)")
//        }
//
//        didSet {
//            print("There are now \(contacts.count) contacts.")
//            print("Old value was \(oldValue)")
//        }
//    }
//}
//
//var app = App()
//app.contacts.append("Adrian E")
//app.contacts.append("Allen W")
//app.contacts.append("Ish S")
//
////Custon initializers
//
//struct Player {
//    var name: String
//    var number: Int
//
//    init(name: String) {
//        self.name = name
//        number = Int.random(in: 1...99)
//    }
//}
//
//let player = Player(name: "Justin T")
//print(player.number)
//
//
//// how do memberwise initializers work
//struct HREmployee {
//    var name: String
//    var yearsActive = 0
//}
//
////
//extension HREmployee {
//    init() {
//        self.name = "Anonymous"
//        print("Creating an anonymous employee…")
//    }
//}
//
//// creating a named employee now works
//let roslin = HREmployee(name: "Laura Roslin")
//
//// as does creating an anonymous employee
//let anon = HREmployee()
//

/*
 Day 11 - Structures PT.2 - Private, public, static - how to limit acces to internal data using access control
 */

    // private - Don't let anything outside the struct use this data
    // fileprivate - Don't let anything outside the current file use this data
    // public - Let anyone, anywhere use this data

    // private(set) - let anyone read this property but only let me internal methods write to it

//Whats the point of access control?
    //they place restrictions about what you can and can't do, and you need to abide by those restrictions
    // by using private im asking swift to enforce the rules for me: dont let me read or write this porperty from anywhere outside the struct
    // lets us control how other people see our code

//struct bankAccount {
//    private(set) var funds: Double = 0
//
//    mutating func deposit(_ amount: Double) {
//        funds += amount
//        print("Your balance is \(funds)")
//    }
//    mutating func withdraw(_ amount: Double) {
//        if funds >= amount{
//            funds -= amount
//        }
//        else {
//            print("not enough funds")
//        }
//        print("Your balance is \(funds)")
//    }
//    func getBalance() {
//        print(funds)
//    }
//}
//
//
//var account = bankAccount(funds: 1000.0)
//// account.funds += 1000 -- private(set) makes this inaccessible
//
//account.deposit(1000.0)
//account.withdraw(2000.0)
//account.getBalance()
//
//
//// Static properties and methods
//struct School {
//    static var studentCount = 0
//
//    static func add(student: String){
//        print("\(student) joined the school")
//        studentCount += 1
//    }
//}
//
//School.add(student: "Taylor Swift")
//print(School.studentCount)
//
//struct NewsStory {
//    static var breakingNewsCount = 0
//    static var regularNewsCount = 0
//    var headline: String
//    init(headline: String, isBreaking: Bool) {
//        self.headline = headline
//        if isBreaking {
//            NewsStory.breakingNewsCount += 1
//        } else {
//            NewsStory.regularNewsCount += 1
//        }
//    }
//}
//
//
//struct Person {
//    static var population = 0
//    var name: String
//    init(personName: String) {
//        name = personName
//        Person.population += 1
//    }
//}
//
//Person.init(personName: "Justin")
//Person.population
//
//struct FootballTeam {
//    static let teamSize = 11
//    var players: [String]
//}
//
//struct Pokemon {
//    static var numberCaught = 0
//    var name: String
//    static func catchPokemon() {
//        print("Caught!")
//        Pokemon.numberCaught += 1
//    }
//}
//
//struct Order {
//    static let orderFormat = "XXX-XXXX"
//    var orderNumber: String
//}
//
//
//// SUMMARY
///*You can create your own structs by writing struct, giving it a name, then placing the struct’s code inside braces.
//Structs can have variable and constants (known as properties) and functions (known as methods)
//If a method tries to modify properties of its struct, you must mark it as mutating.
//You can store properties in memory, or create computed properties that calculate a value every time they are accessed.
//We can attach didSet and willSet property observers to properties inside a struct, which is helpful when we need to be sure that some code is always executed when the property changes.
//Initializers are a bit like specialized functions, and Swift generates one for all structs using their property names.
//You can create your own custom initializers if you want, but you must always make sure all properties in your struct have a value by the time the initializer finishes, and before you call any other methods.
//We can use access to mark any properties and methods as being available or unavailable externally, as needed.
//It’s possible to attach a property or methods directly to a struct, so you can use them without creating an instance of the struct.*/
//
//
///* Check point 6*/
///*create a struct to store information about a car, including its model, number of seats, and current gear, then add a method to change gears up or down. Have a think about variables and access control: what data should be a variable rather than a constant, and what data should be exposed publicly? Should the gear-changing method validate its input somehow?  */
//
//struct Car {
//    private let model: String
//    private let numSeats: Int
//    let maxGears: Int
//
//    private static var gear = 1
//
//    init(model: String, numSeats: Int, maxGears: Int) {
//        self.model = model
//        self.numSeats = numSeats
//        self.maxGears = maxGears
//    }
//
//    mutating func increaseGear(){
//        if Car.gear < self.maxGears {
//            Car.gear += 1
//            print("Gear increased")
//        }
//        else{
//            print("*sound of grinding gears* ~ Can't increase gear")
//        }
//    }
//    mutating func decreaseGear(){
//        if Car.gear > 1 {
//            Car.gear -= 1
//            print("Gear decreased")
//        }
//        else{
//            print("*sound of grinding gears* ~ Can't derease gear")
//        }
//    }
//    func getGear(){
//        print("\(self.model) is riding smooth in gear \(Car.gear)")
//    }
//}
//
//var ferrari = Car(model: "Ferrari", numSeats: 2, maxGears: 10)
//
//for _ in 1...ferrari.maxGears {
//ferrari.increaseGear()
//}
//for _ in 1...ferrari.maxGears {
//ferrari.decreaseGear()
//}
//ferrari.getGear()
//
//
//

/*  DAY 12 - classesCLASSESclasses */

//class Game {
//    var userName = "jtrubela"
//    var email = "jtrubela@netscape.com"
//
//
//    var score = 0{
//        didSet {
//            print("Score is now \(score)")
//        }
//    }
//    func getScore() {
//        print("score is: \(score)")
//    }
//}
//
//var newGame = Game()
//newGame.score += 10
//
//
//var newGameCopy = newGame
//
//newGameCopy.score += 10
//newGame.getScore()
//newGameCopy.getScore()
//
//newGame.score == newGameCopy.score
//
//class VideoGame: Game {
//    func getUserName(){
//        print(userName)
//    }
//    func changeUsername(to newUserName: String) -> String{
//        userName = newUserName
//        return userName
//    }
//}
//
//
//class Employee {
//    var name = "Anonymous"
//    var badgeNumber = 0
//
//    init(name: String, badgeNumber: Int) {
//        self.name = name
//        self.badgeNumber = badgeNumber
//    }
//    init(name: String) {
//        self.name = name
//    }
//    func work(){
//        print("I'm shuffling some papers")
//    }
//}
//
//final class Manager: Employee {
//    override func work() {
//        print("I am managing people")
//    }
//}
//
//final class Developer: Employee {
//    override func work() {
//        print("Im writing some code")
//    }
//}
//
//var leadDeveloper = Developer.init(name: "Justin", badgeNumber: 12)
//leadDeveloper.work()
//var departmentManager = Manager(name: "Justine")
//departmentManager.work()
//
//
//// HOW TO ADD INITIALIZERS FOR CLASSES
//
//class Vehicle {
//    let isElectric: Bool
//
//    init(isElectric: Bool) {
//        self.isElectric = isElectric
//    }
//}
//
//class Car: Vehicle {
//    let isConvertible: Bool
//
//    init(isElectric: Bool, isConvertible: Bool) {
//        self.isConvertible = isConvertible
//       // self.isElectric = isElectric               IS WRONGGGGGG
//        super.init(isElectric: isElectric)          // You need to call a super call to its parent class
//    }
//}
//
//class Student {
//    var name: String
//    init(name: String) {
//        self.name = name
//    }
//}
//class UniversityStudent: Student {
//    var annualFees: Int
//    init(name: String, annualFees: Int) {
//        self.annualFees = annualFees
//        super.init(name: name)
//    }
//}
//
//class Instrument {
//    var name: String
//    init(name: String) {
//        self.name = name
//    }
//}
//class Piano: Instrument {
//    var isElectric: Bool
//    init(isElectric: Bool) {
//        self.isElectric = isElectric
//        super.init(name: "Piano")
//    }
//}
//
//
//// HOW TO COPY CLASSES
//// ALL COPIES OF A CLASS INSTANCE SHARE THE SAME DATA, MEANING THAT ANY CHANGES YOU MAKE TO ONE COPY WILL AUTOMATICALLY CHANGE THE OTHER COPIES
//
//class User {
//    var userName = "Anonymous"
//}
//
//var user0 = User()
//var user3 = user0               // HERE IS THE COPY
//user3.userName = "Taylor"
//
//print(user1.userName)
//print(user3.userName)
//
//
///// it allows us to share common data in alot of parts of our program
/////to bypass this -- "Deep copy" --- by creating a function within our class called copy and returning a copy of our class
//
//
//class AnotherUser {
//    var userName = "Anonymous"
//
//    func copy() -> AnotherUser {
//        let user = AnotherUser()
//        user.userName = userName
//        return user
//    }
//}
//
//var user1 = AnotherUser()
//var user2 = user1.copy()             //HERE IS THE COPY
//user2.userName = "Taylor"
//
//print(user1.userName)
//print(user2.userName)
//
//
//class Author {
//    var name = "Anonymous"
//}
//var dickens = Author()
//dickens.name = "Charles Dickens"
//var austen = dickens
//austen.name = "Jane Austen"
//print(dickens.name)
//print(austen.name)
//
//
/////////////////  HOW TO CREATE A DEINITIALIZER FOR A CLASS ------------------NO PARENTHESIS
///// DEINITIALIZER DESTROYS AN OBJECT
/////Just like initializers, you don’t use func with deinitializers – they are special.
/////Deinitializers can never take parameters or return data, and as a result aren’t even written with parentheses.
/////Your deinitializer will automatically be called when the final copy of a class instance is destroyed. That might mean it was created inside a function that is now finishing, for example.
/////We never call deinitializers directly; they are handled automatically by the system.
/////Structs don’t have deinitializers, because you can’t copy them.
/////
//
//
//class Userss {
//    let id: Int
//
//    init(id:Int) {
//        self.id=id
//        print("User \(id): I'm alive!")
//    }
//    deinit{
//        print("User \(id): I'm dead!")
//    }
//}
//var users = [Userss]()
//
//for i in 1...3 {
//    let user = Userss(id: i)
//    print("User \(user.id): I'm in control!")
//    users.append(user)
//}
//
//print("Loop is finished!")
//users.removeAll()
//print("Array is clear")
//
//
////HOW TO WORK WITH VARIABLES INSIDE CLASSES
/////Variable classes can have variable properties changed
/////Constant classes can have variable properties changed
/////Variable structs can have variable properties changed
/////Constant structs cannot have variable properties changed
//
//class Users {
//    var name = "Paul"
//}
//
//var user = Users()           // NOT THE SAME AS              let user = User()
//user.name = "Taylor"
//user = Users()
//print(user.name)
//
//
//class Pizza {
//    private var toppings = [String]()
//    func add(topping: String) {
//        toppings.append(topping)
//    }
//}
//var pizza = Pizza()
//pizza.add(topping: "Mushrooms")
//
//class Kindergarten {
//    var numberOfScreamingKids = 30
//    func handOutIceCream() {
//        numberOfScreamingKids = 0
//    }
//}
//let kindergarten = Kindergarten()
//kindergarten.numberOfScreamingKids
//kindergarten.handOutIceCream()
//kindergarten.numberOfScreamingKids
//
//
///*  SUMMMARYYYY*/
/////Classes have lots of things in common with structs, including the ability to have properties and methods, but there are five key differences between classes and structs.
/////First, classes can inherit from other classes, which means they get access to the properties and methods of their parent class. You can optionally override methods in child classes if you want, or mark a class as being final to stop others subclassing it.
/////Second, Swift doesn’t generate a memberwise initializer for classes, so you need to do it yourself. If a subclass has its own initializer, it must always call the parent class’s initializer at some point.
/////Third, if you create a class instance then take copies of it, all those copies point back to the same instance. This means changing some data in one of the copies changes them all.
/////Fourth, classes can have deinitializers that run when the last copy of one instance is destroyed.
/////Finally, variable properties inside class instances can be changed regardless of whether the instance itself was created as variable.
//
//
//
///* Checkpoint 7*/
/////make a class hierarchy for animals, starting with Animal at the top, then Dog and Cat as subclasses, then Corgi and Poodle as subclasses of Dog, and Persian and Lion as subclasses of Cat.
/////But there’s more:
//
/////The Animal class should have a legs integer property that tracks how many legs the animal has.
/////The Dog class should have a speak() method that prints a generic dog barking string, but each of the subclasses should print something slightly different.
/////The Cat class should have a matching speak() method, again with each subclass printing something different.
/////The Cat class should have an isTame Boolean property, provided using an initializer.
//
//
//// Parent class for Animals with initializer for number of legs
//class Animal {
//    var legs: Int
//    init(legs: Int) {
//        self.legs = legs
//    }
//}
//
//
////Child of Parent...but parent to Corgi and Poodle
//class Dog: Animal {
//    override init(legs: Int) {
//        super.init(legs: 4)
//    }
//    func speak(){
//        print("Woof Woof")
//    }
//}
//
//final class Corgi: Dog {
//}
//var corgi = Corgi(legs: 4)
//corgi.speak()
//
//final class Poodle: Dog {
//}
//var poodle = Poodle(legs: 4)
//poodle.speak()
//
//class Cat: Animal {
//    var isTame: Bool
//
//    init(isTame: Bool, legs: Int) {
//        self.isTame = isTame
//        super.init(legs: 4)
//    }
//    func speak() {
//        print("Meow")
//    }
//}
//var cat = Cat(isTame: true, legs: 3)
//cat.speak()
//
//final class Persian: Cat {
//    //already domesticated so no need for an overridden isTame initializer but needs one on initialization
////    override init(isTame: Bool, legs: Int) {
////      super.init(isTame: true, legs: 4)             //ONLY IF YOU WANTEDD
////    }
//    //Already meows given it is a child of Cat
////    override func speak() {
////        print("Meow")
////    }
//
//}
//var persian = Persian(isTame: true, legs: 4)
//print(persian.speak())
//print(persian.isTame)
//
//final class Lion: Cat {
//    override init(isTame: Bool, legs: Int) {
//        super.init(isTame: false, legs: 4)
//    }
//    override func speak() {
//        print("Roar")
//    }
//}
//var lion = Lion(isTame: false, legs: 4)
//lion.speak()

///*
// DAY 13 - PROTOCOLS
// */
//
//protocol Vehicle {
//    var name: String {get}
//    var currentPassengers: Int {get set}
//    func estimateTime(for distance: Int) -> Int     // NO FUNCTION BODIES ALLOWED
//    func travel(distance: Int)
//}
//
//protocol CanBeElectric {
//    //some code
//}
//
//// ALL FUNCTIONS INSIDE THE STRUCTURE MUST INCLUDE ONES THAT WERE INITIALIZED DURING THE PROTOCOL
//struct Car: Vehicle, CanBeElectric {        //SHOWS YOU CAN CONORM TO MULTIPLE PROTOCOLS
//    let name = "Car"
//    var currentPassengers = 1
//
//    func estimateTime(for distance: Int) -> Int {
//        distance/50
//    }
//    func travel(distance: Int) {
//        print("I'm driving \(distance)km")
//    }
//    func openSunRoof() {
//        print("It's a nice day!")
//    }
//}
//
//struct Bicycle: Vehicle {
//    let name = "Bike"
//    var currentPassengers = 1
//
//    func estimateTime(for distance: Int) -> Int {
//        distance/10
//    }
//    func travel(distance: Int) {
//        print("I'm cycling \(distance)km")
//    }
//}
//
//func commute(distance: Int, using vehicle: Vehicle){
//    if vehicle.estimateTime(for: distance) > 100 {
//        print("That's to slow! I'll try a different vehicle")
//    }
//    else {
//        vehicle.travel(distance: distance)
//    }
//}
//
//func getTravelEstimates(using vehicles: [Vehicle], distance: Int){
//    for vehicle in vehicles {
//        let estimate = vehicle.estimateTime(for: distance)
//        print("\(vehicle.name): \(estimate) hours to travel \(distance)")
//    }
//}
//
//let car = Car()
//commute(distance: 100, using: car)
//let bicycle = Bicycle()
//commute(distance: 100, using: bicycle)
//getTravelEstimates(using: [car, bicycle], distance: 150)
//
//
//
//struct book {
//    var name: String
//}
//
//func purchase(_ book: book){
//    print("Im buying: \(book)")
//}
//
//var NightTrainToLisbon = book(name: "Night Train To Lisbon")
//purchase(NightTrainToLisbon)
//
//
//
//protocol Purchaseable {
//    var name: String {get set}
//}
//
//struct Book: Purchaseable {
//    var name: String
//    var author: String
//    var publisher: String
//}
//
//struct Movie: Purchaseable {
//    var name: String
//    var producer: String
//    var actors: String
//}
//
//struct Motorcycle: Purchaseable {
//    var name: String
//    var manufacturer: String
//    var numberOfPassengers: Int
//}
//
//var nightTrainToLisbon = Book(name: "Night Train To Lisbon", author: "", publisher: "")
//
//func buy(_ item: Purchaseable){
//    print("I'm buying \(item)")
//}
//
//buy(Book(name: "Night Train To Lisbon", author: "Amedeu De Prado", publisher: "cedar vehlmo"))
//
//
//
//// OPAQUE RETURN TYPES
//
//protocol View { }
//
//func getRandomNumber() -> some Equatable {
//    Int.random(in: 1...6)
//}
//func getRandomBool() -> some Equatable {
//    Bool.random()
//}
//print(getRandomNumber() == getRandomNumber())
//print(getRandomBool() == getRandomBool())
//
//
////PRACTICLE USE OF OPAQUE RETURN TYPES
//// -> some view
//// -> some layout
//// -> some UIView
//// -> some scrollPane
//// -> some ...
//
//
//// HOW TO CREATE AND USE EXTENSIONS
//// Extensions make long wordy methods smaller
//// string has white space and we want to remove it
//var quote = "   The truth is rarely pure and never simple   "
//// trimmingCharacters(in: .whitespacesAndNewlines)
//let trimmed = quote.trimmingCharacters(in: .whitespacesAndNewlines)
//
////==creating the extension
//
//extension String {
//    func trimmed() {
//        self.trimmingCharacters(in: .whitespacesAndNewlines)
//    }
//    var lines: [String] {
//        self.components(separatedBy: .newlines)
//    }
//}
//
//func trim(_ string: String) -> String {
//    string.trimmingCharacters(in: .whitespacesAndNewlines)
//}
//
//let trimmed01: () = quote.trimmed()
//let trimmed2 = trim(quote)
//
//let lyrics = """
//But I keep cruising
//can't stop, wont stop moving
//it's like I got this music in my mind
//staying it's gonna be alright
//"""
//print(lyrics.lines.count)
//
//lyrics.components(separatedBy: .newlines)
//
//
//struct Book1 {
//    let title: String
//    let pageCount: Int
//    let readingHours: Int
//
////    init(title: String, pageCount: Int){
////        self.title = title
////        self.pageCount = pageCount                creating this disables all memberwise initializers made in previous code
////        self.readingHours = pageCount/50
////    }
//}
//
////thats why we use extensions to keep things organized and efficient
//extension Book1{
//
//    init(title: String, pageCount: Int) {
//        self.title = title
//        self.pageCount = pageCount
//        self.readingHours = pageCount/50
//    }
//}
//let lotr = Book1(title: "Lord of the Rings", pageCount: 1178, readingHours: 24)
//
//// When should you use extensions in swift
//// it lets us add functionality to classes, structs, and more, which is helpful for modifyling types we dont own
//
//
//extension String {
//    mutating func append(_ other: String){
//        self += other
//    }
//}
//
//var string1 = "I'm a string"
//var string2 = "waiting to meet my other half"
//var myString: () = string1.append(string2)
//print(myString)
//
//extension Int {
//    var isAnswerToLifeUniverseAndEverything: Bool {
//        let target = 42
//        return self == target
//    }
//}
//
//
////How to create and use protocol extensions
//
//let guests = ["mario", "luigi", "peach"]
//
////  TO CHECK IF ITS NOT EMPTY !guests.isEmpty is propper but messy  //
///**********************************************************************************************************/
///***/           extension /*Array*/ Collection {                   /***/    //isEmpty can be used on all collection types
///***/                   var isNotEmpty: Bool {                     /***/
///***/                       return isEmpty == false                /***/
///***/                   }                                          /***/
///***/                }                                             /***/
///***/                                                              /***/
///***/                if !guests.isEmpty{                           /***/
///***/                    print("Guest count: \(guests.count)")     /***/
///***/                }                                             /***/
///**********************************************************************************************************/
//
//// MAKES THIS MUCH MORE READABLE
//if guests.isNotEmpty {
//    print("Guest count: \(guests.count)")
//}
//
//let numbers = [4, 8, 12, 16]
//let allEven = numbers.allSatisfy { $0.isMultiple(of: 2) }
//
//let numbers2 = Set([4, 8, 15, 16])
//let allEven2 = numbers2.allSatisfy { $0.isMultiple(of: 2) }
//
//let numbers3 = ["four": 4, "eight": 8, "fifteen": 15, "sixteen": 16]
//let allEven3 = numbers3.allSatisfy { $0.value.isMultiple(of: 2) }
//
////protocol Fencer: Int {
////
////}
//
//protocol Fencer {
//    func fenceFoil()
//}
//extension Fencer {
//    func fenceFoil() {
//        print("En garde")
//    }
//}
//
//
////Your challenge is this: make a protocol that describes a building, adding various properties and methods, then create two structs, House and Office, that conform to it. Your protocol should require the following:
////
////A property storing how many rooms it has.
////A property storing the cost as an integer (e.g. 500,000 for a building costing $500,000.)
////A property storing the name of the estate agent responsible for selling the building.
////A method for printing the sales summary of the building, describing what it is along with its other properties.
//protocol Building {
//    var numberOfRooms: Int {get set}
//    var cost: Int {get set}
//    var agent: String {get}
//
//    func printSalesSummary()
//}
//
//extension Building {
//    func printSalesSummary(){
//        print("The Building costs $\(cost) and is being managed by: \(agent).\n It has \(numberOfRooms)")
//    }
//}
//
//struct House: Building {
//    var agent: String
//    var numberOfRooms: Int
//    var numberOfBedrooms: Int
//    var numberOfBathrooms: Int
//    var cost: Int
//
//
//    init(numberOfBedrooms: Int, numberOfBathrooms: Int, cost: Int){
//        agent = "Justin Trubela"
//        numberOfRooms = numberOfBedrooms+numberOfBathrooms+3
//        self.numberOfBedrooms = numberOfBedrooms
//        self.numberOfBathrooms = numberOfBathrooms
//        self.cost = cost
//    }
//
//    func printSalesSummary() {
//        print("This House costs $\(cost) and is being managed by: \(agent).")
//        print("It is a \(numberOfBedrooms) bedroom/\(numberOfBathrooms) bath with a full kitchen/dining area")
//        print("In total there are \(numberOfRooms) rooms")
//
//    }
//}
//
//struct Office: Building {
//    var agent: String
//    var numberOfRooms: Int
//    var cornerOffice: Bool
//    var numberOfOffices: Int
//    var numberOfConferenceRooms: Int
//    var cost: Int
//
//    init(agent: String, cornerOffice: Bool, numberOfConferenceRooms: Int, numberOfOffices: Int, cost: Int) {
//        self.agent = agent
//        self.cost = cost
//        self.cornerOffice = cornerOffice
//        self.numberOfOffices = numberOfOffices
//        self.numberOfConferenceRooms = numberOfConferenceRooms
//
//        numberOfRooms = numberOfConferenceRooms+numberOfOffices+3
//        if cornerOffice==true {
//            numberOfRooms += 1
//        }
//
//    }
//
//    func printSalesSummary() {
//        var costAgentSummary =  "The Office costs $\(cost) and is being managed by: \(agent)."
//        let layoutSummary = "\nIt has a \(numberOfConferenceRooms) conference rooms, \(numberOfOffices) offices, it's own eatery, and 2 bathrooms"
//        let totalRooms = "\nTotal of rooms: \(numberOfRooms)"
//        if cornerOffice{
//            let cornerOfficeSummary = " It has a corner office."
//            costAgentSummary.append(cornerOfficeSummary)
//            print(costAgentSummary + layoutSummary + totalRooms)
//        }
//        else{
//            print(costAgentSummary + layoutSummary + totalRooms)
//        }
//    }
//}
//
//var RiversideHouse = House(numberOfBedrooms: 4, numberOfBathrooms: 2, cost: 200_000)
//RiversideHouse.printSalesSummary()
//
//var MainStBusinessPark = Office(agent: "Justin Trubela", cornerOffice: true, numberOfConferenceRooms: 2, numberOfOffices: 4, cost: 600_000)
//MainStBusinessPark.printSalesSummary()
//

//
///*
// DAY 14 - Nil Coalescing
// */
//
//var username: String? = nil
//
//if let unwrappedName = username {
//    print("We got a user: \(unwrappedName)")
//} else {
//    print("The optional was empty")
//}
//
//var num1: Int = 1
//var num2: Int = 2
//var num3: Int? = nil
//
//var str1 = "hello"
//var str2 = ""
//var str3: String? = nil
//
//func square (number: Int) -> Int {
//    number * number
//}
//
//var number: Int? = nil
//
//if let number = number {
//    print(square(number: number))
//}
//
//func findGreatestValueInList(list: [Int])->Int? {
//    if list.count == 0 {
//        return nil
//    }
//
//    var greatestValue = -1
//    for number in list {
//        if number > greatestValue {
//            greatestValue = number
//        }
//    }
//    return greatestValue
//}
//
//[1,2,3].max()
//
//func printSquare(of number: Int?) {
//    guard let number = number else {
//        print("Missing input")
//        return
//    }
//    print("\(number) * \(number) is \(number * number)")
//}
//
//printSquare(of: number)
//
//func playOpera(by composer: String?) -> String? {
//    guard let composer = composer else{
//        return "Please specify a composer."
//    }
//    if composer == "Mozart" {
//        return "Le nozze di Figaro"
//    } else {
//        return nil
//    }
//}
//if let opera = playOpera(by: "Mozart") {
//    print(opera)
//}
//
//func uppercase(string: String?) -> String? {
//    guard let string = string else {
//        return nil
//    }
//    return string.uppercased()
//}
//if let result = uppercase(string: "Hello") {
//    print(result)
//}
//
////func add3(to number: Int) -> Int {
////    guard let number = number else {
////        return 3
////    }
////    return number + 3
////}
////let added = add3(to: 5)
////print(added)
//
////func username(for id: Int?) -> String {
////    guard let id = id else {
////        return nil
////    }
////    if id == 1989 {
////        return "Taylor Swift"
////    } else {
////        return nil
////    }
////}
//
//func plantTree(_ type: String?) {
//    guard let type = type else {
//        return
//    }
//    print("Planting a \(type).")
//}
//plantTree("willow")
//
//
//let captains = [
//    "Enterprise": "Picard",
//    "Voyager" : "Janeway",
//    "Defiant": "Sisko"
//]
//
//let nemesis = [ "Mario": "Wario",
//                "Spiderman": "Green Goblin",
//                "Batman": "Penguin",
//]
//
//let new = captains["Serenity"] ?? "N/A"
//
////let new = captains["Serenity", default: "N/A"]        Dictionary Default
//
//let tvShows = ["Archer", "Babylon 5", "Ted Lasso"]
//let favorite  = tvShows.randomElement() ?? "None"
//
//struct Book {
//    let title: String
//    let author: String?
//}
//
//
//let book = Book(title: "Beowulf", author: nil)
//let author = book.author ?? "Anonymous"
//
//let input = ""
//let number5 = Int(input) ?? 0
//print(number5)
//
//
//
//// chaining optionals  -  if the optional has a value inside, unwrap it then...
//
//let names = ["arya", "Bran", "Robb", "Sansa"]
//let chosen = names.randomElement()?.uppercased() ?? "No one"
//print("Next in line: \(chosen)")
//
//struct Bookk {
//    let title: String
//    let author: String?
//}
//
////var bookk = Bookk? = nil
////let author = bookk?.author.first?.uppercased() ?? "A"
//
//let namess = ["Vincent": "van Gogh", "Pablo": "Picasso", "Claude": "Monet"]
//let surnameLetter = namess["Vincent"]?.first?.uppercased()
//
//
//let credentials = ["twostraws", "fr0sties"]
//let lowercaseUsername = credentials.first?.lowercased()
//
//func albumReleased(in year: Int) -> String? {
//    switch year {
//    case 2006: return "Taylor Swift"
//    case 2008: return "Fearless"
//    case 2010: return "Speak Now"
//    case 2012: return "Red"
//    case 2014: return "1989"
//    case 2017: return "Reputation"
//    default: return nil
//    }
//}
//let album = albumReleased(in: 2006)?.uppercased()
//
//let attendees: [String]? = [String]()
//let firstInLine = attendees?.first?.uppercased()
//
//let racers = ["Hamilton", "Verstappen", "Vettel"]
//let winnerWasVE = racers.first?.hasPrefix("Ve")
//
////How to handle function failure with optionals
//
//enum UserError: Error{
//    case badID, networkFailed
//}
//
//func getUser(id: Int) throws -> String {
//    throw UserError.networkFailed
//}
//if let user = try? getUser(id: 23) {
//    print("user: \(user)")
//}
//
//let user = ( try? getUser(id: 23)) ?? "Anonymous"
//
//
//// Summary
////Let’s recap what we learned:
////
////Optionals let us represent the absence of data, which means we’re able to say “this integer has no value” – that’s different from a fixed number such as 0.
////As a result, everything that isn’t optional definitely has a value inside, even if that’s just an empty string.
////Unwrapping an optional is the process of looking inside a box to see what it contains: if there’s a value inside it’s sent back for use, otherwise there will be nil inside.
////We can use if let to run some code if the optional has a value, or guard let to run some code if the optional doesn’t have a value – but with guard we must always exit the function afterwards.
////The nil coalescing operator, ??, unwraps and returns an optional’s value, or uses a default value instead.
////Optional chaining lets us read an optional inside another optional with a convenient syntax.
////If a function might throw errors, you can convert it into an optional using try? – you’ll either get back the function’s return value, or nil if an error is thrown.
//
//
///*
// Now that you understand a little about optionals, it’s time to pause for a few minutes and try a small coding challenge so you can see how much you’ve remembered.
//
// If that sounds easy, it’s because I haven’t explained the catch yet: I want you to write your function in a single line of code. No, that doesn’t mean you should just write lots of code then remove all the line breaks – you should be able to write this whole thing in one line of code.
//
// Still here? Okay, here are some hints:
//
// Your function should accept an [Int]? – an array of integers that might be there, or might be nil.
// It needs to return a non-optional Int.
// You can use optional chaining to call randomElement() on the optional array, which will in turn return another optional.
// Because you need to return a non-optional integer, you should use nil coalescing to pick a random number from 1 through 100.
// */
//
//
//
////
////Your challenge is this: write a function that accepts an optional array of integers, and returns one randomly. If the array is missing or empty, return a random number in the range 1 through 100.
//
//func arrayRandomizer(_ num:[Int]?) -> Int? {
//    if let num = num {
//        return num.randomElement()
//    }
//    return Int.random(in: 1...100)
//}
//let array = [Int]()
//print(arrayRandomizer(array) ?? 69)




//// DAY 15
//import UIKit
//import Foundation
//
//let greeting = "Hello, playground"
//var greetingCopy = greeting
//let myNumber = 5
//var myNumberCopy = myNumber
//let myBool = false
//var myBoolCopy = myBool
//let myStringArray = ["string1","string2","string3","string4"]
//var myStringArrayCopy = myStringArray
//let myIntArray = [1,2,3,4]
//var myIntArrayCopy = myIntArray
//let myBoolArray = [true,false]
//var myBoolArrayCopy = myBoolArray
//
//
////learned methods
//
//// String Methods
//greetingCopy.hasPrefix("Hello")
//greetingCopy.hasSuffix("ground")
//greetingCopy.count
//greetingCopy.append(contentsOf: "! Welcome")
//greetingCopy.uppercased()
//
////Integer Methods
//myNumberCopy.isMultiple(of: 2)
//
////Boolean Methods
//myBoolCopy.toggle()
//
////Array Methods
//myStringArrayCopy.count
//myStringArrayCopy.append("string5")
//myIntArrayCopy.remove(at: 1)
//
////Quotes
//var quote = "This is a quote written by me: \"I am the only one who can make my dreams happen.\" like that"
//
////Incrementers
//myNumberCopy += 5
//
////Toggling Booleans
//myBoolCopy.toggle()
//
////sets refresher - can't add duplicates and return no specific order
//var numbers = Set([1,1,2,4,7,9])
//numbers.insert(10)
////print(numbers)
//
////enums refresher - list of items that are finite; days of week/months; cases
//enum daysOfWeek {
//    case Monday,Tuesday,Wednesday,Thursday,Friday,Saturday,Sunday
//}
//enum monthsOfYear {
//    case January, February, March, April, May, June, July, August, September, October, November, December
//}
//let monday = daysOfWeek.Monday
//let firstMonth = monthsOfYear.January
//var day = daysOfWeek.Monday
////Assigning enum to variable
//day = .Friday
//
////Dictionary refresher
//var weekday = [1: "Monday"]
//var weekDays = [1: "Monday", 2: "Tuesday"]
//
//print(weekday)
//weekday[1]
//
//
////Type annotation
//var myScore: Double = 0
//
////Switch refresher
//enum Weather {
//    case rainy, sunny, snowy, foggy, windy, thunder
//}
//
//var forecast = Weather.sunny
//switch forecast {
//case .rainy: print("It's rainy")
//case .sunny: print("It's sunny")
//case .snowy: print("It's snowing")
//case .foggy: print("It's foggy")
//case .windy: print("It's windy")
//default: print("Not sure, might be a thunderstorm")
//}
//
//
////Ternary Conditional operator What: TRUE or FALSE - WTF
//var myAge = 17
//let myVotingAge = myAge >= 18 ? "Yes" : "No"
//
//
////Loop Refresher
//let myPlatforms = ["iOS", "TvOS", "iPadOS"]
//for os in myPlatforms {
//    print(os)
//}
//for _ in myPlatforms {
//    //some code
//}
//for item in 1...3 {
//    print(myIntArray[item])
//}
//
//
//// Throwing errors
//
//enum PasswordError: Error {
//    case short, obvious
//}
//
//func checkPassword(_ password: String) throws -> String {
//    if password.count < 5 {
//        throw PasswordError.short
//    }
//
//    if password == "12345" {
//        throw PasswordError.obvious
//    }
//
//    if password.count < 10 {
//        return "OK"
//    } else {
//        return "Good"
//    }
//}
//
//let myPassword = "12345"
//
//do {
//    let result = try checkPassword(myPassword)
//    print("Rating: \(result)")
//} catch PasswordError.obvious {
//    print("I have the same combination on my luggage!")
//} catch {
//    print("There was an error.")
//}
//
//
////Closures
//let mySayHello = {
//    print("Hi there!")
//}
//
//mySayHello()
//
//
//let sayHello = { (name: String) -> String in
//    "Hi \(name)!"
//}
//
//let team = ["Gloria", "Suzanne", "Tiffany", "Tasha", "Bam","smoke","Justin"]
//
//let onlyT = team.filter({ (name: String) -> Bool in
//    return name.hasPrefix("T")
//})
//
//
////struct <#name#> {
////    <#fields#>
////}
//
//
//
//
//
//
//          BUTTONS GRADIENTS COLORS
//import UIKit
//
//var greeting = "Hello, playground"
//
//
//LinearGradient(gradient: Gradient(colors: [.white,.black]), startPoint: .top, endPoint: .bottom).ignoresSafeArea()
//
//
//
//
//ZStack{
//    VStack(spacing: 0){
//        Color.red
//        Color.blue
//    }.ignoresSafeArea()
//
//    VStack{
//Spacer()
//        Text("SOME CONTENT")
//            .foregroundColor(.black
//            )
//            .padding(50)
//            .background(
//                LinearGradient(gradient: Gradient(stops: [
//                Gradient.Stop(color: .blue, location: 0.45),
//                Gradient.Stop(color: .yellow, location: 0.55)
//            ]), startPoint: .top, endPoint: .bottom)
//                .ignoresSafeArea())
//
//        Text("YOUR CONTENT")
//            .foregroundColor(.black)
//            .padding(50)
//            .background(AngularGradient(
//                gradient:Gradient(
//                    colors: [.red,.yellow,.green,.blue,.purple,.red]),
//                    center: .center)
//            .ignoresSafeArea())
//
//Spacer()
//Spacer()
//Spacer()
//
//        Text("MORE CONTENT")
//            .foregroundColor(.black)
//            .padding(50)
//            .background(LinearGradient(
//                gradient: Gradient(stops: [
//                .init(color: .white, location: 0.45),
//                .init(color: .green, location: 0.55)
//            ]), startPoint: .top, endPoint: .bottom))
//        Text("SOME MORE CONTENT")
//            .foregroundColor(.black)
//            .padding(25)
//            .background(
//                RadialGradient(
//                    gradient: Gradient(colors: [.red,.black]),
//                    center: .center,
//                    startRadius: 20, endRadius: 200)
//            .ignoresSafeArea()
//
//            )
//Spacer()
//Spacer()




//                                  BUTTONS                                  //





//ZStack {
//    Color.green.ignoresSafeArea()
//    VStack{
//        Button("Button 1"){
//        }.buttonStyle(.bordered)
//
//        Button("Button 2", role: .destructive){
//        }.buttonStyle(.bordered).tint(.primary)
//
//        Button("Button 3"){}
//        .buttonStyle(.borderedProminent)
//
//        Button("Button 4", role: .destructive){}
//        .buttonStyle(.borderedProminent)
//
//        Button{
//            print("Button was tapped")
//        } label: {
//            Label("Edit", systemImage: "pencil").foregroundColor(.black)
//        }.buttonStyle(.borderedProminent).buttonStyle(.borderedProminent).tint(.white)
//
//        // if for some reason the image you choose gets colored in completely use
//        // the .renderingMode(.original) modifier
//    }
//
//    }
//}





//                                  BUTTONS & Alerts                                  //






//struct ContentView: View {
//
//    @State private var showingAlert = false //Swift waits for this alert to become true
//
//    var body: some View {
//        Button("Show alert"){
//            showingAlert = true
//        }
//        .alert("Important message", isPresented: $showingAlert){
//            Button("Delete", role: .destructive){ }
//            Button("Cancel", role: .cancel){ }
//        } message: {
//            Text("Please read this")
//        }
//    }
//}

//
//print("                 *       / \\             *         ")
//print("      *                 /   \\   *                  ")
//print("            *          /     \\      *           *   ")
//print(" *                     |     |                     *")
//print("       *               |  W  |            *         ")
//print("                 *     |  E  |  *                *   ")
//print("  *                    |  B  |              *       ")
//print("            *          |  B  |       *              ")
//print("     *                 |     |  *                   ")
//print("                 *    /       \\               *    ")
//print(" *      *            /         \\           *       ")
//print("     *       *      |           |    *           *   ")
//print("   *                |           |           *       ")
//print("                 *  |___________|      *        *    ")
//print("     *               /\\/\\/\\/\\/\\/\\   *         *")
//




//****************************************************************************************//
//                                    DATE AND TIME                                       //
//****************************************************************************************//






//@State private var sleepAmount = 8.0
//@State private var sleep = 8
//@State private var wakeUp = Date.now
//****************************************************************************************
// Stepper options
//****************************************************************************************


//Stepper("\(sleepAmount.formatted()) hours", value: $sleepAmount, in: 4...12, step: 0.25)

//Stepper("\(sleep) hours", value: $sleep, in: 4...12, step: 2)


//****************************************************************************************
// DatePickers
//****************************************************************************************


                        // if you want the title gone just use the modifier
//DatePicker("some title", selection: $wakeUp).labelsHidden()
//        DatePicker("some title", selection: $wakeUp, displayedComponents: .hourAndMinute)
//        DatePicker("some title", selection: $wakeUp, displayedComponents: .date)
//        DatePicker("some title", selection: $wakeUp, in:
//              Date.now...Date.now.addingTimeInterval(86400))
//
//        DatePicker("some title", selection: $wakeUp, in:Date.now...Date.now.addingTimeInterval(86400)
//        ,displayedComponents: .date)
//
//        DatePicker("Please enter a date", selection: $wakeUp)
//

//****************************************************************************************
// Working with dates ---- Getting specific componets from the date using DateComponents()
//****************************************************************************************

//Text(Date.now, format: .dateTime.hour().minute())
   
//Text(Date.now, format: .dateTime.day().month().year())                //Dec 27, 2021
//Text(Date.now.formatted(date: .omitted, time: .shortened))            //1:05 PM
//Text(Date.now.formatted(date: .omitted, time: .standard))             // 1:06:47 -> 1:06:48 updating
//Text(Date.now.formatted(date: .omitted, time: .complete))             // 1:05:51 PM EST -> 1:05:52 PM EST updating

//Text(Date.now.formatted(date: .complete, time: .omitted))             // Monday, December 27, 2021
//Text(Date.now.formatted(date: .abbreviated, time: .omitted))          // Dec 27, 2021
//Text(Date.now.formatted(date: .long, time: .omitted))                 // December 27, 2021
//Text(Date.now.formatted(date: .numeric, time: .omitted))              // 12/27/21

//    func exampleDate() {
//        let tomorrow = Date.now.addingTimeInterval(86400)
//        let range = Date.now...tomorrow
//    }
    //func trivialExample() {
//        let components = Calendar.current.dateComponents([.hour, .minute], from: Date.now)
//        let hour = components.hour ?? 0
//        let minute = components.minute ?? 0
        
        //OR
        
//        var components = DateComponents()
//        components.hour = 8
//        components.minute = 0
//        let date = Calendar.current.date(from: components) ?? Date.now
//    }







//****************************************************************************************
//MACHINE LEARNING
//****************************************************************************************



//***********************************************************************************
// LISTS           LOADING IN DATA FROM OUTSIDE        WORKING WITH STRINGS
//***********************************************************************************

////    func test() {
////        let input = """
////A
////B
////C
////"""
////        let letters = input.components(separatedBy: "\n")
////        let letter = letters.randomElement()
////
////        let trimmed = letter?.trimmingCharacters(in: .whitespacesAndNewlines)
////            //          THIS RETURNS AN OPTIONAL STRING BECAUSE SWIFT DOESNT KNOW AT COMPILE TIME THAT THE ARRAY IS EMPTY OR NOT
////    }
//
//    func test(){
//        let word = "swift"
//        let checker = UITextChecker()
//
//        //determine range of string check
//        //start at 0 and go to utf16 length possible
//        let range = NSRange(location: 0, length: word.utf16.count)
//        //checking a string word, what range of check, starting where to start inside that range, when its finished wrap to beginning? false, english language used
//        let misspelledRange = checker.rangeOfMisspelledWord(in: word, range: range, startingAt: 0, wrap: false, language: "en")
//        //if word is spelled correctly otherwise it be false
//        let allGood = misspelledRange.location == NSNotFound
//    }
//
//    var body: some View {
//        Text("Hello, world!")
//            .padding()
//
//
//    //components(separatedBy: ".asdfas.")
//    //
//

//***********************************************************************
//                  USING LISTSSSS IN YOUR VIEW
//***********************************************************************
//        List(people, id:\.self){
//            Text($0)
//        }.listStyle(.grouped)
//
//        List{
//            Text("Static Row")
//            ForEach(people, id: \.self){
//                Text($0)
//            }
//            Text("Static Row")
//        }
//
//        List{
//            //Dynamic Text
//            ForEach(0..<11){
//                Text("Dynamic \($0)")
//            }
//            //Static in Dynamic
//            Text("Static 1")
//        }.listStyle(.sidebar)
//
//        List{
//            //Static Text
//            Text("Static")
//        }
////        .listStyle(.automatic)
////        .listStyle(.inset)    //undistinguished on top of background
////        .listStyle(.insetGrouped) //distinguished rounded rectagle - regular listview
////        .listStyle(.sidebar) //collapsable information
////        .listStyle(.grouped) //edge to edge white background
////        .listStyle(.plain) //all white background
//
//        List{
//            Section("Group 1 Static"){
//                Text("Group 1 - 01")
//                Text("Group 1 - 02")
//                Text("Group 1 - 03")
//            }
//            Section("Group 2 Dynamic"){
//                ForEach(0..<5){
//                    Text("Dynamic - 0\($0)")
//                }
//            }
//            Section("Group 3 Static"){
//                Text("Group 1 - 04")
//                Text("Group 1 - 05")
//            }
//        }.listStyle(.insetGrouped)

        
//    }
    
//***********************************************************************
//              LOADING IN FILES TO YOUR APP
//If we want to read the URL for a file in our main app bundle, we use Bundle.main.url()
//
//Once we have a URL, we can load it into a string with a special initializer: String(contentsOf:). We give this a file URL, and it will send back a string containing the contents of that file if it can be loaded. If it can’t be loaded it throws an error, so you you need to call this using try or try? like this:

//if let fileContents = try? String(contentsOf: fileURL) {
        // we loaded the file into a string!
//} after that its just a regular string
//***********************************************************************

//
//    func loadFile() {
//        if let fileURL = Bundle.main.url(forResource: "text-file", withExtension: "txt"){
//            if let fileContents = try? String(contentsOf: fileURL){
//                //We loaded the file into the string
//                fileContents // now you can do what you want with that string
//            }
//        }
////    }
//
//
//}
//
//struct ContentView_Previews: PreviewProvider {
//    static var previews: some View {
//        ContentView()
//    }
//}
//


//******************************************************************************
// Day 36 -- iExpense -
//   PROPERTY WRAPPERS
//@State, @published, @ObservedObject, @EnvironmentObject
//                      @StateObject, @AppStorage with tags
//
//                      UserDefaults
//                      : ObservableObject protocol
//                      Dismiss Button/ EditButton
//******************************************************************************


// Sharing data across views using 3 property wrappers
// @State is for sharing across local view

// @StateObject  --  @ObservedObject  -- @EnvironmentObject

// @Published - we want to notify our views that are watching our class that a change has happened

// shared bindings between views
// @StateObject - just to be used when first creating the data
// @ObservedObject - when modifying the object - when you are just reading and writing

// avoid using Private access controls when sharing data across views to eliminate confusion
// any class must conform to the ObservableObject protocol if intending to share data across views


//
//import SwiftUI
//
//class User: ObservableObject {
//    @Published var firstName = "Bilbo"
//    @Published var lastName = "Baggins"
//}
//
//struct ContentView: View {
//
//    @StateObject private var user = User()
//
//    var body: some View {
//
//        VStack {
//            Text("Your name is \(user.firstName) \(user.lastName)")
//
//            TextField("First name", text: $user.firstName)
//            TextField("Last name", text: $user.lastName)
//
//        }
//    }
//}
//




// Sharing/Showing views in SwiftUI - sheet - a new view presented on top of our existing one. (credit card-like presentation)
// define the conditions in which the sheet should be shown
// and when those conditions become true of false the sheet will either be presented or dismissed respectively

//making a view dismiss itself -- program it to dismiss it self programatically
//@Environment(\.dismiss) var dismiss





//import SwiftUI
//
//struct SecondView: View {
//    @Environment(\.dismiss) var dismiss
//
//    let name: String
//
//    var body: some View {
//        ZStack{
//            Color.green.ignoresSafeArea()
//            Button("Dismiss"){
//                dismiss()
//            }
//        }
//    }
//}
//
//struct ContentView: View {
//   // Some State to track whether the sheet is showing
//    @State private var showingSheet = false
//
//    var body: some View {
//
//        Button("Show Sheet") {
//            //Show sheet by toggling when button is tapped
//            showingSheet.toggle()

//         // attach our sheet to our view heirarchy
//        }.sheet(isPresented: $showingSheet) {
//            SecondView(name: "@twostraws")
//        }
//    }
//}





// Deleting items using onDelete()
// control how objects are deleted from a collection - only exists on ForEach in List



// onDelete()
//    func removeRows(at offsets: IndexSet){
//        numbers.remove(atOffsets: offsets)
//    }
// EditButton mindblownnnnnn


//import SwiftUI
//
//
//struct ContentView: View {
//
//    @State private var numbers = [Int]()
//    @State private var currentNumber = 1
//
//
//    var body: some View {
//
//        NavigationView  {
//            VStack{
//                List {
//                    ForEach(numbers, id: \.self){
//                        Text("Row \($0)")
//                        // calll that method when it wants to delete data from the ForEach with this modifier
//                    }.onDelete(perform: removeRows)
//                }
//                Button("Add Number"){
//                    numbers.append(currentNumber)
//                    currentNumber += 1
//                }
//            }.navigationTitle("On Delete")
//                .toolbar {
//                    EditButton()
//                }
//            }
//
//    }
//    // tells us the positions of all the items in the ForEach that should be removed
//    // because our ForEach was created entirely from a signle array, we can actually just pass that index set
//    // it has a speciale remove(atOffsets:) method that accepts an index set
//    func removeRows(at offsets: IndexSet){
//        numbers.remove(atOffsets: offsets)
//    }
//}
//







// Storing user settings with UserDefaults!!!!!!!
// One common way to read and write small amounts of user data -- UserDefaults easy for simple data
// Aim to store no more than 512 KB
// gets stored automatically when app loads
// if you store alot it will become really slow
// things like when user launched the app last, which story they were using last, or other passively collected information

// SwiftUI can wrap up UserDefaults inside a property wrapper called @AppStorage - only supports a subset of functionality as of right now



// we want to save the number of taps that the user made
// write UserDefaults inside button works but setting the variable directly to userDefaults is better

// 1. We need to use UserDefaults.standard
//  built in instance of userdefaults that is attachd to our app
//  very useful to create your own if you have several views

// 2. set() -- method that accepts any kind of data -- integers, Bools, strings, and more

// 3. set("STRING") -- we attach strings name of what we are storing as a key for the system to remember
//      case sensitive
//      we need to use the same key to read the data back out of UserDefaults


// Sometimes having default values like 0 is helpful but other times it can be confusing like for bools
// was it false to begin with or was it false because the user made it that way -- its confusing

// it takes a while for ios to write your data to permanent storage


///struct ContentView: View {
///   @State private var tapCount = UserDefaults.standard.integer(forKey: "Tap")
///
///   var body: some View {
///
///       Button("Tap count: \(tapCount)") {
///           tapCount += 1
///           UserDefaults.standard.set(self.tapCount, forKey: "Tap")
///       }
///
///   }
///


// using @AppStorage property wrapper around userDefaults
// 1. out acces to the UserDegaults system is through @AppStorage wrapper. This works like @State: when the value changes,
//      it will reinvoke the body property so our UI reflects the new data
// 2. we attach a string name, which is the UserDefualts key where we want to store the data. - it doesnt need to match the property name
// 3. Rest of body is declared as normal, including providing a default value of 0

// @AppStorage is easier than UderDefaults because we dont have to repeat the same key twice
//      however, right now at least @AppStorage doesnt make it easy to handle storing complex objects such as swift structs
//              because ios doesnt want us to store lots of data in there


//
//import SwiftUI
//
//
//struct ContentView: View {
//    @AppStorage("tapCount") private var tapCount = 0
//
//    var body: some View {
//
//        Button("Tap count: \(tapCount)") {
//            tapCount += 1
//        }
//
//    }
//}
//
//
//struct ContentView_Previews: PreviewProvider {
//    static var previews: some View {
//        ContentView()
//    }
//}





// Arching Swift objects with Codable
// @AppStorage is easy for simple types, more work involved for custom swift types
// working with Structs we use Codable -- still need to tell it when to do it
//  swift will automatically generate J(ava) S(cript) O(object) N(otation) format to be stored and read back out again

// call the json using an JSONEncoder to store and use JSONDecoder to retrieve


// Codable : a protocol specifically for archiving and unarchiving data - convertig objects into plain text and back again
// any custom swift types need to conform to the codable protocol
// make sure to use a try block to catch any errors


//import SwiftUI
//
//struct User: Codable {
//    let firstName: String
//    let lastName: String
//}
//
//
//struct ContentView: View {
//
//    @State private var user = User(firstName: "Taylor", lastName: "Swift")
//    var body: some View {
//
//        Button("Save User"){
//            let encoder = JSONEncoder()
//
//            if let data = try? encoder.encode(user) {
//                UserDefaults.standard.set(data, forKey: "UserData")
//            }
//        }
//
//    }
//}
//
//
//import SwiftUI
//
//struct User: Codable {
//    let firstName: String
//    let lastName: String
//}
//
//
//struct ContentView: View {
//
//    @State private var user = User(firstName: "Taylor", lastName: "Swift")
//    var body: some View {
//        VStack{
//            Text("User Name: \(user.firstName) \(user.lastName)")
//        }
//        Button("Save User"){
//            let encoder = JSONEncoder()
//
//            if let data = try? encoder.encode(user) {
//                UserDefaults.standard.set(data, forKey: "UserData")
//            }
//        }
//
//    }
//}
//
//
//struct ContentView_Previews: PreviewProvider {
//    static var previews: some View {
//        ContentView()
//    }
//}








                        // Day 39 - Project 8 - Moonshot app
                        //
                        //Resizing Images to fit the screen using Geometry Reader
                        //How ScrollView lets us work with scrolling data
                        //Pushing new views onto the stack using NavigationLink
                        //Working with hierarchical Codable data
                        //How to lay out views in a scrolling grid
                        //


//struct ContentView: View {
//    var body: some View {
//        Text("Hello, world!")
//            .padding()
//    }
//}
//
//struct ContentView_Previews: PreviewProvider {
//    static var previews: some View {
//        ContentView()
//    }
//}
//

//Resizing images
//New kind of view - Geometry Reader
    //.frame()
    //.clipped()
    //.resizable()              Standard image customizers modifiers
    //.scaledToFit()
    //.scaledToFill()

//  --Geometry Reader--
//  centering view -- add a second frame
//    Content
//      .frame(width: geo.size.width * 0.8)
//      .frame(width: geo.size.width, height: geo.size.height)

//struct ContentView: View {
//    var body: some View {
//        GeometryReader{ geo in
//            Image("Image")
//                .resizable()
//                .scaledToFit()
//                .frame(width: geo.size.width * 0.8)
//                .frame(width: geo.size.width, height: geo.size.height)
//        }
//
//    }
//}


//struct CustomText: View {
//    let text: String
//
//    var body: some View {
//        Text(text)
//    }
//
//    init(_ text: String) {
//        print("Creating a new CustomText")
//        self.text = text
//    }
//}
//
//struct ContentView: View {
//    var body: some View {
//
//        ScrollView{
//            LazyVStack(spacing:10){
//                ForEach(0..<100) {
//                    CustomText("Item \($0)")
//                        .font(.title)
//                }
//            }
//            .frame(maxWidth:.infinity, maxHeight: .infinity)
//
//        }
//    }
//}

// NAVIGATION LINK -- Pushing new views onto the stack
//struct ContentView: View {
//    var body: some View {
//
//        NavigationView {
//            NavigationLink{
//                Text("Detail View")
//            } label: {
//                Text("Hello, world!")
//            }
//            .navigationTitle("SwiftUI")
//        }
//    }
//}


// Producing list of navigationLinkable rows
//
//
//struct ContentView: View {
//    var body: some View {
//
//        NavigationView {
//
//            List(0..<100) { row in
//                NavigationLink{
//                    Text("Detail \(row)")
//                } label: {
//                    Text("Row \(row)")
//                }
//            .navigationTitle("SwiftUI")
//            }
//        }
//    }
//}

// Codable Data
// Make separate classes of data containing an array or arrays of different objects
// Decode JSON

//
//struct User: Codable {
//    let name: String
//    let address: Address
//}
//
//struct Address: Codable {
//    let street: String
//    let city: String
//}
//
//
//struct ContentView: View {
//    var body: some View {
//        Button("Decode JSON") {
//            let input = """
//            {
//                "name": "Taylor Swift",
//                "address": {
//                    "street": "555 Taylor Swift Avenue",
//                    "city": "Nashville"
//                }
//            }
//            """
//
//            let data = Data(input.utf8)
//
//            if let user = try? JSONDecoder().decode(User.self, from: data) {
//                print(user.address.street)
//            }
//        }
//    }
//}
//
//struct ContentView_Previews: PreviewProvider {
//    static var previews: some View {
//        ContentView()
//    }
//}




// How to lay out views in a scrolling grid
// Vertical Scroll Grid - standard


//struct ContentView: View {
//    let layout = [
//        GridItem(.fixed(80)),
//        GridItem(.fixed(80)),
//        GridItem(.fixed(80))
//    ]
//
//    var body: some View {
//        ScrollView{
//            LazyVGrid(columns: layout) {
//                ForEach(0..<1000) {
//                    Text("Item \($0)")
//                }
//            }
//        }
//    }
//}

// Vertical Scroll Grid - adaptive to screen size

//
//struct ContentView: View {
//    let layout = [
//        GridItem(.adaptive(minimum: 80, maximum: 120))
//    ]
//
//    var body: some View {
//        ScrollView{
//            LazyVGrid(columns: layout) {
//                ForEach(0..<1000) {
//                    Text("Item \($0)")
//                }
//            }
//        }
//    }
//}



// Horizontal Scroll Grid - adaptive to screen size
// change scroll view to .horizontal
// columns to rows
// LazyVstack to LazyHstack


//struct ContentView: View {
//    let layout = [
//        GridItem(.adaptive(minimum: 80, maximum: 120))
//    ]
//
//    var body: some View {
//        ScrollView(.horizontal){
//            LazyHGrid(rows: layout) {
//                ForEach(0..<1000) {
//                    Text("Item \($0)")
//                }
//            }
//        }
//    }
//}

var roman = "VIII"

print(roman.count)

roman
